fx_version 'adamant'

game 'gta5'

description 'BlackBooks Player Movement Mechanics'

version '1.0'

client_scripts {
	'client/*.lua'
}